HƯỚNG DẪN — TOUR KHÁM PHÁ HẦM CHỈ HUY T1 KÈM BẢNG THÔNG TIN (BẢN GỌN)

ĐƯỜNG DẪN TOUR ĐANG NHÚNG
https://tour.panoee.net/iframe/6adadaeeb4d45c7f0fe64efb?embedFullscreen=1&embedVr=1&embedGyro=1

THAY ĐỔI GIAO DIỆN
- Thu nhỏ bảng thông tin, đưa bảng lên cao hơn ở góc trên bên trái.
- Nền tối trong suốt hơn, viền và bóng nhẹ để ảnh 360° vẫn là phần nổi bật.
- Cỡ chữ và khoảng cách được giảm; bộ chọn nội dung thuyết minh gọn hơn và xếp 2 cột trên máy tính, 1 cột trên màn hình nhỏ.
- Có đủ nội dung: Lối vào hầm, Phòng giao ban, Phòng trực ban kháng chiến, Phòng Lọc độc.
- Có bộ chọn dự phòng để người xem đổi nội dung thủ công; query `?room=loi-vao-ham`, `?room=phong-giao-ban`, `?room=phong-truc-ban-khang-chien`, `?room=phong-loc-doc` dùng để mở sẵn nội dung tương ứng.
- Đã thêm bộ lắng nghe các thông điệp đổi cảnh từ iframe Panoee nếu trình phát phát ra sự kiện có tên cảnh tương ứng.

GIỚI HẠN QUAN TRỌNG VỀ ĐỒNG BỘ THANH CẢNH PANOEE
Tour đang chạy trong iframe khác tên miền (`tour.panoee.net`). Trình duyệt không cho trang bao ngoài đọc thao tác bấm trong iframe. Đoạn mã nhúng người dùng cung cấp chỉ chuyển tiếp dữ liệu gyroscope; không có API/sự kiện đổi cảnh được tài liệu hóa trong mã đó. Vì vậy, bộ lắng nghe mới chỉ đồng bộ tự động nếu iframe gửi thông điệp tên cảnh. Nếu Panoee không phát thông điệp này, bộ chọn dự phòng vẫn đổi được nội dung nhưng không thể theo dõi trực tiếp cú bấm vào thanh cảnh gốc.

Để đảm bảo đúng 100% khi bấm các thumbnail gốc, cần một trong các cách: (1) thêm nội dung Article/Text/Hotspot theo từng scene ngay trong Panoee Studio; hoặc (2) lấy dữ liệu scene và dùng API được Panoee hỗ trợ / dựng lại bằng trình xem có thể điều khiển từ trang ngoài. Không thể đảm bảo đồng bộ hoàn toàn chỉ bằng cách sửa CSS/JS bên ngoài iframe.

CÁCH DÙNG
1. Giải nén ZIP.
2. Tải tất cả nội dung bên trong lên thư mục gốc của hosting tĩnh, giữ nguyên thư mục `static`, `_next` và các tệp khác.
3. Mở `index.html` từ hosting có kết nối Internet. Tour cần còn được Panoee cho phép nhúng.

CÁC FILE PANOEE GỐC
Các trang export gốc được giữ riêng: `index-panoee-export-original.html` và `export-full-panoee-original.html`.
